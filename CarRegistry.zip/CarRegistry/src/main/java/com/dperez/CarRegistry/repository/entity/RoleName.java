package com.dperez.CarRegistry.repository.entity;

public enum RoleName {
    ROLE_ADMIN,
    ROLE_CLIENT,
    ROLE_VENDOR
}
