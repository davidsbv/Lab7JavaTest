package com.dperez.CarRegistry.service.impl;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CarServiceImplTest {

    @Test
    void addCar() {
    }

    @Test
    void addBunchCars() {
    }

    @Test
    void getCarById() {
    }

    @Test
    void updateCarById() {
    }

    @Test
    void updateBunchCars() {
    }

    @Test
    void deleteCarById() {
    }

    @Test
    void getAllCars() {
    }
}